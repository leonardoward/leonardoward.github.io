var optionsState =  {

    // The create function is a  standard Phaser function, and is automatically called.
    create: function() {



        // this.game.input.onDown.add(this.changeVolume, this);

        var level1 = game.add.button(game.world.centerX-25 / 2, game.world.centerY-150, "level1t",this.MuteVolume,this);
        level1.anchor.set(0.5);

        var level2= game.add.button(game.world.centerX-25 / 2, game.world.centerY, "level2t");
        level1.anchor.set(0.5);

        // goback button
        var replay= game.add.button(this.game.world.centerX-50,this.game.world.centerY+225, "back",this.goBack,this);

    },


    goBack: function(){


        this.game.state.start('menu');

    },

    MuteVolume: function() {

        if (this.game.global.music.mute==true)
        {
            this.game.global.music.mute = false;
        }

        else
        {
            this.game.global.music.mute=true;
        }

    }






};
