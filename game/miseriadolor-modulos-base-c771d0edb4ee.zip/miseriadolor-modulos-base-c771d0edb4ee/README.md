# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

Repositorio del Servicio comunitario
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

Todo esta ordenado de acuerdo  a este tutorial (http://perplexingtech.weebly.com/game-dev-blog/using-states-in-phaserjs-javascript-game-developement)
Excepto que renombré el estado **play** por  **level1** en la esperanza de agregar más niveles (level1, level2, ....) en archivos independientes que
se puedan invocar desde el menú.

### Contribution guidelines ###

Hay un master con el juego que llevo, y un branck con mi nombre que es con el que voy a estar trabajando.
Si van a trabajar, hagan un branch con sus nombre y luego cuadramos cómo hacemos el Merge.

### Who do I talk to? ###

**Personas Jodidas:**
Cristhian Bravo
Said Alvarado
Leonardo Ward.
